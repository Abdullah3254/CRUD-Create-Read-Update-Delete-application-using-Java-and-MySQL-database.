import java.util.List;

public class Main {
    public static void main(String[] args) {
        UserDao userDao = new UserDao();
        User newUser = new User("Muhammad Abdullah", "abdullahlodhi471@gmail.com");
        userDao.createUser(newUser);
        List<User> users = userDao.readUsers();
        for (User user : users) {
            System.out.println(user.getId() + ": " + user.getName() + " - " + user.getEmail());
        }
        if (!users.isEmpty()) {
            User userToUpdate = users.get(0);
            userToUpdate.setName("Muhammad Abdullah");
            userToUpdate.setEmail("abdullahlodhi471@gmail.com");
            userDao.updateUser(userToUpdate);
        }
        if (!users.isEmpty()) {
            User userToDelete = users.get(0);
            userDao.deleteUser(userToDelete.getId());
        }
        users = userDao.readUsers();
        for (User user : users) {
            System.out.println(user.getId() + ": " + user.getName() + " - " + user.getEmail());
        }
    }
}
